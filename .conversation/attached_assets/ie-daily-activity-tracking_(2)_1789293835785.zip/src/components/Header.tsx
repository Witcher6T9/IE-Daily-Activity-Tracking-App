import React, { useState, useRef, useEffect } from 'react';
import { PageId, UiTheme, AutoUpdateSettings, CustomRoleDefinition, RolePerson, TierDefinition, GoogleUserSession, CloudSyncState } from '../types';
import {
  Settings,
  Shield,
  User,
  Gauge,
  RefreshCw,
  Sun,
  Moon,
  Trees,
  Flame,
  Cpu,
  Check,
  Bell,
  ListTodo,
  ChevronDown,
  Layers,
  Settings2,
  Lock,
  LogOut,
  CloudLightning,
  CloudOff,
  Radio,
  Database,
  Award
} from 'lucide-react';

interface HeaderProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  roleLabel: string;
  currentRoleKey?: string;
  pinLocked?: boolean;
  onLockApp?: () => void;
  uiTheme: UiTheme;
  onChangeTheme: (theme: UiTheme) => void;
  autoUpdate?: AutoUpdateSettings;
  onToggleAutoUpdate?: () => void;
  onManualSync?: () => void;
  isSyncing?: boolean;
  lastSyncTime?: Date;
  onOpenNotifications?: () => void;
  unreadNotificationCount?: number;
  onSelectRole?: (roleKey: string, matchedPersonName?: string) => void;
  customRoles?: CustomRoleDefinition[];
  rolePeople?: RolePerson[];
  onOpenCreateCustomRole?: () => void;
  // Tier-based customizable system
  tiers?: TierDefinition[];
  activeTierId?: string;
  onSelectTier?: (tierId: string) => void;
  onOpenTierCustomizer?: () => void;
  // User Account & Login Options
  googleUser?: GoogleUserSession;
  onOpenGoogleAuth?: () => void;
  onGoogleSignOut?: () => void;
  // Cloud Data Sync & Live Telemetry
  cloudSyncState?: CloudSyncState;
  onOpenCloudSync?: () => void;
}

const THEME_OPTIONS: { id: UiTheme; label: string; icon: React.FC<{ className?: string }>; color: string }[] = [
  { id: 'light', label: 'Clean Light', icon: Sun, color: '#0284c7' },
  { id: 'dark', label: 'Twilight Dark', icon: Moon, color: '#818cf8' },
  { id: 'forest', label: 'Mint Forest', icon: Trees, color: '#059669' },
  { id: 'sunset', label: 'Warm Amber', icon: Flame, color: '#ea580c' },
  { id: 'industrial', label: 'Titanium Steel', icon: Cpu, color: '#38bdf8' }
];

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  roleLabel,
  currentRoleKey = 'admin',
  pinLocked,
  onLockApp,
  uiTheme,
  onChangeTheme,
  autoUpdate,
  onToggleAutoUpdate,
  onManualSync,
  isSyncing = false,
  lastSyncTime,
  onOpenNotifications,
  unreadNotificationCount = 0,
  onSelectRole,
  customRoles = [],
  rolePeople = [],
  onOpenCreateCustomRole,
  tiers = [],
  activeTierId = 'tier_1',
  onSelectTier,
  onOpenTierCustomizer,
  googleUser,
  onOpenGoogleAuth,
  onGoogleSignOut,
  cloudSyncState,
  onOpenCloudSync
}) => {
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const themeMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (themeMenuRef.current && !themeMenuRef.current.contains(e.target as Node)) {
        setShowThemeMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const activeTier = tiers.find(t => t.id === activeTierId) || tiers[0] || {
    id: 'tier_1',
    level: 1,
    name: 'IE Operations Manager',
    shortCode: 'T1',
    color: 'violet',
    description: 'Head of Industrial Engineering',
    canManageTierLevels: [2, 3],
    allowSelfAssignment: true,
    canCreateTodos: true,
    canCreateSchedules: true,
    canEditLineData: true,
    canApproveChecklist: true
  };

  const currentThemeObj = THEME_OPTIONS.find(t => t.id === uiTheme) || THEME_OPTIONS[0];
  const CurrentThemeIcon = currentThemeObj.icon;

  const formatLastSync = (d?: Date) => {
    if (!d) return 'Just now';
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80 transition-colors">
      <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between">
        <div 
          onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center text-white shadow-sm shadow-teal-500/20 group-hover:scale-105 transition-transform">
            <Gauge className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-bold text-slate-900 text-sm leading-tight tracking-tight flex items-center gap-1.5">
              <span>IE Tracking</span>
              <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200/60">
                PROD
              </span>
            </div>
            <div className="text-[11px] text-slate-500 font-medium">
              Industrial Engineering • Apparel Systems
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Automatic Updates Live Indicator & Sync Trigger */}
          {autoUpdate && (
            <div className="hidden sm:flex items-center gap-1.5 bg-slate-50/90 border border-slate-200/90 rounded-xl px-2.5 py-1 text-xs">
              <button
                onClick={onToggleAutoUpdate}
                title={autoUpdate.enabled ? `Auto-Updates Active (${autoUpdate.intervalSeconds}s interval). Click to pause.` : 'Auto-Updates Paused. Click to resume.'}
                className="flex items-center gap-1.5 font-semibold text-slate-700 hover:text-blue-600 transition"
              >
                <span className="relative flex h-2 w-2">
                  {autoUpdate.enabled && (
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  )}
                  <span className={`relative inline-flex rounded-full h-2 w-2 ${autoUpdate.enabled ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                </span>
                <span className="text-[11px] uppercase tracking-wider">
                  {autoUpdate.enabled ? 'Auto' : 'Paused'}
                </span>
              </button>
              <button
                onClick={onManualSync}
                title={`Last synced: ${formatLastSync(lastSyncTime)}. Click to force update.`}
                className="p-1 text-slate-400 hover:text-blue-600 rounded-md transition hover:bg-slate-200/60"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-blue-600' : ''}`} />
              </button>
            </div>
          )}

          {/* Quick Theme Selector Popover */}
          <div className="relative" ref={themeMenuRef}>
            <button
              onClick={() => setShowThemeMenu(!showThemeMenu)}
              title={`Active Theme: ${currentThemeObj.label}. Click to change.`}
              className="h-9 px-2.5 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-blue-600 hover:border-blue-200 flex items-center gap-1.5 transition shadow-2xs text-xs font-semibold"
            >
              <CurrentThemeIcon className="w-4 h-4" />
              <span className="hidden md:inline text-[11px] font-medium text-slate-600">
                {currentThemeObj.label}
              </span>
            </button>
            {showThemeMenu && (
              <div className="absolute right-0 mt-2 w-48 rounded-2xl bg-white border border-slate-200 shadow-xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
                <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                  Select Visual Theme
                </div>
                {THEME_OPTIONS.map(opt => {
                  const Icon = opt.icon;
                  const isSelected = uiTheme === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => {
                        onChangeTheme(opt.id);
                        setShowThemeMenu(false);
                      }}
                      className={`w-full px-3 py-2 flex items-center justify-between text-xs text-left transition hover:bg-slate-50 ${
                        isSelected ? 'font-bold text-blue-600 bg-blue-50/60' : 'text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Icon className="w-3.5 h-3.5" style={{ color: opt.color }} />
                        <span>{opt.label}</span>
                      </div>
                      {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* To-Do & Time Scheduling Quick Link */}
          <button
            onClick={() => onNavigate('todo-schedule')}
            title={`Active System Role: ${activeTier.name} (T${activeTier.level}) - Click to manage tasks, schedules, and active tier`}
            className={`h-9 px-3 rounded-xl border flex items-center gap-1.5 transition shadow-2xs text-xs font-bold ${
              currentPage === 'todo-schedule'
                ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                : 'border-slate-200 bg-white text-slate-700 hover:text-blue-600 hover:border-blue-200'
            }`}
          >
            <span className="w-5 h-5 rounded-md bg-blue-100 text-blue-800 flex items-center justify-center text-[10px] font-black">
              T{activeTier.level}
            </span>
            <span className="hidden sm:inline">Role: {activeTier.shortCode || activeTier.name}</span>
          </button>

          {/* Individual IE & Roles Monthly KPI Reports */}
          <button
            onClick={() => onNavigate('kpi-reports')}
            title="Individual IE & Roles Monthly KPI Reports"
            className={`h-9 px-3 rounded-xl border flex items-center gap-1.5 transition shadow-2xs text-xs font-bold ${
              currentPage === 'kpi-reports'
                ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                : 'border-slate-200 bg-white text-slate-700 hover:text-blue-600 hover:border-blue-200'
            }`}
          >
            <Award className="w-4 h-4 text-blue-600" />
            <span className="hidden md:inline">Monthly KPI</span>
          </button>

          {/* Enterprise Database & Storage Center */}
          <button
            onClick={() => onNavigate('database')}
            title="Full Database & Storage Management Center"
            className={`h-9 px-3 rounded-xl border flex items-center gap-1.5 transition shadow-2xs text-xs font-bold ${
              currentPage === 'database'
                ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                : 'border-slate-200 bg-white text-slate-700 hover:text-blue-600 hover:border-blue-200'
            }`}
          >
            <Database className="w-4 h-4 text-blue-600" />
            <span className="hidden md:inline">Database</span>
          </button>

          {/* Floor Push Notifications Bell */}
          {onOpenNotifications && (
            <button
              onClick={onOpenNotifications}
              title="Notifications & Floor Alerts"
              className="relative w-9 h-9 rounded-xl border border-slate-200 bg-white text-slate-600 hover:text-blue-600 hover:border-blue-200 flex items-center justify-center transition shadow-2xs"
            >
              <Bell className="w-4 h-4" />
              {unreadNotificationCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white font-black text-[9px] flex items-center justify-center animate-pulse">
                  {unreadNotificationCount > 9 ? '9+' : unreadNotificationCount}
                </span>
              )}
            </button>
          )}

          {/* Live Cloud Data Sync Indicator & Trigger */}
          {onOpenCloudSync && (
            <button
              onClick={onOpenCloudSync}
              title={`Cloud Data Sync: ${cloudSyncState?.status.toUpperCase() || 'LIVE'} - ${cloudSyncState?.cloudEndpoint || 'WebSocket Connected'} (Click to manage sync)`}
              className="h-9 px-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 transition flex items-center gap-1.5 shadow-2xs text-xs font-bold"
            >
              <span className="relative flex h-2 w-2">
                {cloudSyncState?.status === 'syncing' ? (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                ) : (cloudSyncState?.status === 'live' || !cloudSyncState?.status) ? (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                ) : null}
                <span
                  className={`relative inline-flex rounded-full h-2 w-2 ${
                    cloudSyncState?.status === 'live' || !cloudSyncState?.status
                      ? 'bg-emerald-500'
                      : cloudSyncState?.status === 'syncing'
                      ? 'bg-blue-500'
                      : cloudSyncState?.status === 'error'
                      ? 'bg-rose-500'
                      : 'bg-slate-400'
                  }`}
                ></span>
              </span>
              <CloudLightning className="w-3.5 h-3.5 text-blue-600 hidden sm:inline" />
              <span className="hidden md:inline">
                {cloudSyncState?.status === 'live'
                  ? `Live (${cloudSyncState.latencyMs}ms)`
                  : cloudSyncState?.status === 'syncing'
                  ? 'Syncing...'
                  : 'Cloud Live'}
              </span>
            </button>
          )}

          {/* 2. USER ACCOUNT & LOGIN OPTIONS BUTTON */}
          {onOpenGoogleAuth && (
            <div>
              {googleUser?.isSignedIn ? (
                <button
                  onClick={onOpenGoogleAuth}
                  title={`Signed in as ${googleUser.name} (${googleUser.email || googleUser.authProvider || 'Active'}) - Click to manage user session`}
                  className="h-9 px-2.5 rounded-xl border border-slate-200 bg-white hover:bg-blue-50/50 text-slate-700 hover:border-blue-300 transition flex items-center gap-2 shadow-2xs"
                >
                  <div className="relative">
                    <img
                      src={googleUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=128&h=128&fit=crop&crop=faces'}
                      alt={googleUser.name}
                      className="w-5 h-5 rounded-full object-cover border border-slate-200"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 ring-1 ring-white" />
                  </div>
                  <div className="hidden lg:flex flex-col text-left">
                    <span className="text-[11px] font-bold text-slate-800 leading-none truncate max-w-[110px]">
                      {googleUser.name}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono leading-tight truncate max-w-[110px]">
                      {googleUser.authProvider ? `${googleUser.authProvider.toUpperCase()}` : (googleUser.email || 'Online')}
                    </span>
                  </div>
                </button>
              ) : (
                <button
                  onClick={onOpenGoogleAuth}
                  title="User Log In Options (Google, Corporate SSO, Floor PIN, Demo Mode)"
                  className="h-9 px-3 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 hover:text-slate-900 transition flex items-center gap-2 shadow-2xs text-xs font-bold"
                >
                  <User className="w-3.5 h-3.5 text-blue-600" />
                  <span className="hidden sm:inline">Log In Options</span>
                  <span className="sm:hidden">Log In</span>
                </button>
              )}
            </div>
          )}

          {/* Settings button */}
          <button
            onClick={() => onNavigate('settings')}
            title="Settings & System Tools"
            className={`w-9 h-9 rounded-xl border flex items-center justify-center transition shadow-2xs ${
              currentPage === 'settings'
                ? 'bg-blue-50 text-blue-600 border-blue-300 ring-2 ring-blue-100'
                : 'border-slate-200 bg-white text-slate-600 hover:text-blue-600 hover:border-blue-200'
            }`}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
